<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SurveyController;
use App\Http\Controllers\StationController;
use App\Http\Controllers\StationManagerController;
use App\Http\Controllers\DealerController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ChecklistController;
use App\Http\Controllers\SafetyController;
use App\Http\Controllers\FeedbackController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/dashboard', function () {
    return view('welcome');
})->name('dashboard');

Route::resource('feedback', FeedbackController::class);

Auth::routes();

Route::middleware(['auth'])->group(function () {
    Route::resource('dealers', DealerController::class)->middleware('can:manage_dealers');
    Route::resource('stations', StationController::class)->middleware('can:manage_stations');
    Route::resource('station_managers', StationManagerController::class)->middleware('can:manage_station_managers');
    Route::resource('users', UserController::class)->middleware('can:manage_users');
    Route::put('users/{user}/deactivate', [UserController::class, 'deactivate'])->name('users.deactivate');
    Route::put('users/{user}/activate', [UserController::class, 'activate'])->name('users.activate');
    Route::resource('surveys', SurveyController::class);
    Route::post('/surveys/{survey}/approve', [SurveyController::class, 'approve'])->name('surveys.approve');
    Route::resource('checklists', ChecklistController::class)->middleware('can:manage_checklists');
    Route::resource('hsseq', SafetyController::class)->middleware('can:manage_safeties');
    Route::post('/safety/{report}/assign-task', [SafetyController::class, 'assignTask'])->name('safety.assignTask');
    Route::get('/safeties/pending', [SafetyController::class, 'pendingSafeties'])->name('safeties.pending');
    Route::post('/safeties/close-task/{id}', [SafetyController::class, 'closeTask'])->name('safeties.closeTask');
    Route::get('/safeties/closed-tasks', [SafetyController::class, 'closedTasks'])->name('safeties.closedTasks');


});


