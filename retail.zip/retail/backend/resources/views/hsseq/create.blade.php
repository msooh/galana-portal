@extends('layouts.main')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"> <b> New Accident/Incident Report</b></div>
                <div class="card-body">
                    <form class="row g-3" method="POST" enctype="multipart/form-data" action="{{ route('hsseq.store') }}">
                        @csrf
                        <div class="col-md-6">
                            <label for="type" class="form-label"><b>Type</b><span class="text-danger">*</span></label>
                            <select id="type" class="form-select" name="type" required>
                                <option value="">Select Type</option>
                                <option value="Accident">Accident</option>
                                <option value="Incident">Incident</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="station_id" class="form-label"><b>Select Station</b><span class="text-danger">*</span></label>
                            <select id="station_id" class="form-select" name="station_id" required>
                                @foreach($stations as $station)
                                    <option value="{{ $station->id }}">{{ $station->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="date" class="form-label"><b>Date</b><span class="text-danger">*</span></label>
                            <input type="date" class="form-control" id="date" name="date" value="{{ date('Y-m-d') }}" required>
                        </div>
                        <div class="col-md-6">
                            <label for="time" class="form-label"><b>Time</b><span class="text-danger">*</span></label>
                            <input type="time" class="form-control" id="time" name="time" value="{{ date('H:i') }}" required>
                        </div>
                        <div class="col-md-6">
                            <label for="comment" class="form-label"><b>A. Comment</b><span class="text-danger">*</span></label>
                            <textarea class="form-control" name="comment" id="" cols="20" rows="3" placeholder="Type Comment" required></textarea>
                        </div>
                        <div class="col-md-6">
                            <label for="action" class="form-label"><b>B. Action</b><span class="text-danger">*</span></label>
                            <textarea class="form-control" name="action" id="" cols="20" rows="3" placeholder="Details of Action Taken" required></textarea>
                        </div>
                        <div class="col-md-12">
                            <label for="dealer_id" class="form-label"><b>C. Nature of Accident/Incident</b><span class="text-danger">*</span></label>
                            <select id="accident_type_id" class="form-select" name="accident_type_id" required>
                                <option value="">Select Nature of Accident</option>
                                @foreach($accidents as $accident)
                                <option value="{{ $accident->id }}">{{ $accident->name }}</option>
                            @endforeach
                            </select>
                        </div>
                        <label for="Injury" class="form-label"><b>D. Injury</b><span class="text-danger">*</span></label>
                        <div class="col-md-6">
                            <label for="slightly_injured" class="form-label">Number of slightly injured persons given 1st aid (if applicable)</label>
                            <input type="number" class="form-control" id="slightly_injure
                            d" name="slightly_injured">
                        </div>
                        <div class="col-md-6">
                            <label for="injured_medical_treatment" class="form-label">Number of injured persons with medical treatment (if applicable)</label>
                            <input type="number" class="form-control" id="injured_medical_treatment" name="injured_medical_treatment">
                        </div>
                        <div class="col-md-6">
                            <label for="injured_hospitalization" class="form-label">Number of injured persons with hospitalization (if applicable)</label>
                            <input type="number" class="form-control" id="injured_hospitalization" name="injured_hospitalization">
                        </div>
                        <div class="col-md-6">
                            <label for="fatalities" class="form-label">Number of Fatalities (if applicable)</label>
                            <input type="number" class="form-control" id="fatalities" name="fatalities">
                        </div>
                        <div class="col-md-12">
                            <label for="other_details" class="form-label"><b>E. Other Details</b><span class="text-danger">*</span></label>
                            <textarea class="form-control" name="other_details" id="other_details" cols="20" rows="3"></textarea>
                        </div>                    

                        <div class="col-md-6">
                            <label for="police_report" class="form-label">Matter reported to Police? (Tick as appropriate)</label>
                            <input type="checkbox" id="police_report_yes" name="police_report" value="YES">
                            <label for="police_report_yes">YES</label>
                            <input type="checkbox" id="police_report_no" name="police_report" value="NO">
                            <label for="police_report_no">NO</label>
                        </div>
                        <div class="col-md-12">
                            <label for="police_file" class="form-label">Police file attachment (if applicable)</label>
                            <input type="file" name="police_file" id="police_file" class="form-control">
                        </div>

                        <div class="col-12">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>



<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
@if(session('success'))
Swal.fire({
    icon: 'success',
    title: 'Success',
    text: '{{ session('success') }}',
    showConfirmButton: false,
    timer: 2000
});
@endif

@if($errors->any())
Swal.fire({
    icon: 'error',
    title: 'Validation Error',
    text: '{!! implode('\\n', $errors->all()) !!}',
    confirmButtonText: 'OK'
});
@endif
</script>
@endsection