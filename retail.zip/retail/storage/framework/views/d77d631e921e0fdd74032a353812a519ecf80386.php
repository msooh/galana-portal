<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Galana System')); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

    <!-- Vendor -->
    <link href="<?php echo e(asset('vendors/bootstrap/bootstrap5/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('vendors/bootstrap/css/bootstrap-toggle.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!--Styles-->
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/dashboard.css')); ?>" rel="stylesheet">
    
    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
</head>
<body>

    <div class="wrapper d-flex flex-column min-vh-100 bg-light">
        <!-- resources/views/_header.blade.php -->
        <?php echo $__env->make('layouts.topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="body flex-grow-1 px-3">
          <?php echo $__env->yieldContent('content'); ?>
      </div>
        <!-- Footer -->
      <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div> 
      
    <script src="<?php echo e(asset('vendors/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/jquery/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/@coreui/coreui/js/coreui.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/simplebar/js/simplebar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/bootstrap/bootstrap5/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/bootstrap/js/bootstrap-toggle.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\retail\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>