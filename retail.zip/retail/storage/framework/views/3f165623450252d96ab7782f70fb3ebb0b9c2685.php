<!DOCTYPE html>
<html>
<head>
    <title>New Anonymous Feedback</title>
</head>
<body>
    <h1>New Anonymous Feedback</h1>
    <p><strong>Feedback Type:</strong> <?php echo e($feedback->feedbackType); ?></p>
    <p><strong>Feedback:</strong> <?php echo e($feedback->feedback); ?></p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\retail\Modules/Feedback\Resources/views/emails/feedback.blade.php ENDPATH**/ ?>