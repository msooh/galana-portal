<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Retail\\Providers\\RetailServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Retail\\Providers\\RetailServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);