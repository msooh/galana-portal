<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Suggestion\\Providers\\SuggestionServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Suggestion\\Providers\\SuggestionServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);