<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\HSSEQ\\Providers\\HSSEQServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\HSSEQ\\Providers\\HSSEQServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);