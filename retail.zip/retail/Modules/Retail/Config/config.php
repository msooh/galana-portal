<?php

return [
    'name' => 'Retail'
];
