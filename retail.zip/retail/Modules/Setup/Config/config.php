<?php

return [
    'name' => 'Setup'
];
