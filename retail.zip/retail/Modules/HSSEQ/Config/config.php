<?php

return [
    'name' => 'HSSEQ'
];
