<?php

namespace Modules\HSSEQ\Entities;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class IncidentAssignment extends Model
{
    use HasFactory;
}
