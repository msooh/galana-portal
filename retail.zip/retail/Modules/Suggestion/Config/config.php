<?php

return [
    'name' => 'Suggestion'
];
