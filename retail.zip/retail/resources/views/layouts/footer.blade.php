<footer class="footer">
    <div><a href="https://www.galanaenergies.com">Galana Energies Limited </a><a href="https://www.galanaenergies.com"></a> © <?php echo date("Y"); ?>.</div>
    <div class="ms-auto"> RMS &nbsp;</div>
</footer>